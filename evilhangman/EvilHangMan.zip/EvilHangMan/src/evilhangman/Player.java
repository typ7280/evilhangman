/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evilhangman;

/**
 *
 * @author Student Lab
 */
public class Player {
    int length;
    char letter;
    
    public void inputLength(int number){
        
    }
    
    public char guess(char letter){
        return letter;
    }
}
